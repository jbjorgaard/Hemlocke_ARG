package org.apache.ibatis.mapping;

public enum ResultFlag {
  ID, CONSTRUCTOR
}
