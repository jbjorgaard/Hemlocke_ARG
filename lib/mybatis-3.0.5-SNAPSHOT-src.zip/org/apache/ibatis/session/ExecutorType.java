package org.apache.ibatis.session;

public enum ExecutorType {
  SIMPLE, REUSE, BATCH
}
